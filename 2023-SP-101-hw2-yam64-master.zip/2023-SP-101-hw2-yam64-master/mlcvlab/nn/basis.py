# No additional 3rd party external libraries are allowed
import numpy as np

def linear(x, W):
    # TODO
    return np.dot(x,W)
    #raise NotImplementedError("Linear function not implemented")
    
def linear_grad(x):
    return x
    #raise NotImplementedError("Gradient of Linear function not implemented")

def radial(x, W):
    # TODO
    raise NotImplementedError("Radial Basis function not implemented")
    
def radial_grad(loss_grad_y, x, W):
    # TODO
    raise NotImplementedError("Gradient of Radial Basis function not implemented")



"""
training: a Boolean flag indicating whether 
the function is being called during training or testing.
x: the input tensor or array
p: the dropout rate

If training=True, the function generates a binary mask
using np.random.binomial(1, p, size=x.shape) with probability p.
It then applies the mask to the input x by multiplying it 
element-wise with x and dividing by p.
This simulates the effect of dropout during training.

If training=False, the function simply returns the input x, without any scaling.
This simulates the effect of using all neurons during testing or inference.
"""
def inverse_dropout(x, p=0.5, training=True):
    if training:
        mask = np.random.binomial(1, p, size=x.shape)
        return mask * x / p
    else:
        return x