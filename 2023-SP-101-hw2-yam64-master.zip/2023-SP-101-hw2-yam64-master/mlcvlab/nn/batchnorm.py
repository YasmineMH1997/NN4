# No additional 3rd party external libraries are allowed
import numpy as np


def batchnorm(x, gamma=1, beta=0.5, eps=1e-8, train=True):
    '''
    Input:
    - x: Data of shape (M, D)
    - gamma: Scale parameter of shape (D,)
    - beta: Shift paremeter of shape (D,)
    - mode: 'train' or 'test'; required
    output:
    - y
    Suggestion: When you return the output, also return the necessary intermediate values (i.e. mu, variance, x_norm) needed in gradient computation
    '''
    if train:

        M, D = x.shape
        # M is number of data points and D is number of neurons
        running_mu = np.zeros(D,dtype=x.dtype)
        running_var = np.zeros(D,dtype=x.dtype)
        # TODO
        mu = np.mean(x, axis=0)
        var = np.var(x, axis=0)
        x_norm = (x - mu) / np.sqrt(var + eps)
        y = gamma * x_norm + beta
        # Update running average of mu and var
        running_mu = 0.9 * mu + 0.1 * running_mu
        running_var = 0.9 * var + 0.1 * running_var
        return y
        #, mu, var, x_norm
        #raise NotImplementedError("Batchnorm Not Implemented")
    else:
        x_norm = (x - running_mu) / np.sqrt(running_var + eps)
        y = gamma * x_norm + beta

        return y

def batchnorm_grad(dy, x, gamma=1, beta=0.5, eps=1e-8):
    # TODO
    M, D = x.shape
    mu = np.mean(x, axis=0)
    var = np.var(x, axis=0)
    x_norm = (x - mu) / np.sqrt(var + eps)

    dx_norm = dy*gamma # eqn 1 in paper
    dvar = np.sum(dx_norm * (x - mu), axis=0) * -0.5 * ((var + eps) ** -1.5) # eqn 2 in paper
    dmu = np.sum(dx_norm * -1 / np.sqrt(var + eps), axis=0) # eqn 3 in paper

    dx = dx_norm / np.sqrt(var + eps) + dvar * 2 * (x - mu) / M + dmu / M # eqn 4 in paper
    dgamma = np.sum(dy * x_norm, axis=0) # eqn 5 in paper
    dbeta = np.sum(dy, axis=0) # eqn 6 in paper
    return dx, dgamma, dbeta
    #raise NotImplementedError("Gradiant of Batchnorm Not Implemented")
