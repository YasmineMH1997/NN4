# No additional 3rd party external libraries are allowed
import numpy as np
"""
credits to:
https://deepnotes.io/dropout#:~:text=A%20Bernoulli%20random%20variable%20is%20defined%20as%20f,forward%20and%20backward%20pass%2C%20which%20is%20essentially%20dropout.
"""
def dropout(x, p, mode='train'):
    '''
    Output : should return a tuple containing 
     - z : output of the dropout
     - p : Dropout param
     - mode : 'test' or 'train'
     - mask : 
      - in train mode, it is the dropout mask
      - in test mode, mask will be None.
    
    sample output: (z=, p=0.5, mode='test',mask=None)
    '''
    # TODO Implement logic for both 'test' and 'train' modes.
    if mode == 'train':
        mask = np.random.binomial(n=1, p=p, size=x.shape) / p
        z = mask * x
        
        
        return z, p, mode, mask
    elif mode == 'test':
        z = x
        return z, p, mode, None
    
"""
The dropout_grad function computes the gradient of the 
dropout layer with respect to its input, which is the same 
in both training and testing modes. 
"""

def dropout_grad(z,mask):

    # TODO Implement the gradient computation for dropout. 
    # Note that this is just a constant multiplier since there are no 
    # model parameters in a dropout mask. 
    """ 
    Input:
     - z : output of the dropout
     - mask : the dropout mask
    
    Output:
     - The gradient of the dropout layer with respect to its input
    """
    dz = mask * z
    return dz
    
    """if mode == 'train':
        raise NotImplementedError("Gradiant of Dropout - Train Not Implemented")
    
    elif mode == 'test':
        raise NotImplementedError("Gradiant of Dropout - Test Not Implemented")"""