# No additional 3rd party external libraries are allowed
import numpy as np

def Adam(model,  train_X, train_y):
    #TODO
    alpha=0.001
    beta1=0.9
    beta2=0.999
    epsilon=1e-9
    epochs = 100
    m1, m2 = np.zeros_like(model.layers[0].W), np.zeros_like(model.layers[1].W)
    v1, v2 = np.zeros_like(model.layers[0].W), np.zeros_like(model.layers[1].W)
    for i in range(epochs):
        # Compute the empirical loss gradient
        grad_W1, grad_W2 = model.emp_loss_grad(train_X,train_y, model.layers, 0)

        # Update the first set of weights
        m1 = beta1 * m1 + (1 - beta1) * grad_W1
        v1 = beta2 * v1 + (1 - beta2) * (grad_W1 ** 2)
        m1_hat = m1 / (1 - beta1 ** (i+1))
        v1_hat = v1 / (1 - beta2 ** (i+1))
        w1_update = alpha * m1_hat / (np.sqrt(v1_hat) + epsilon)
        #w1_update[np.isnan(w1_update)] = 0  # Replace NaN with zero
        model.layers[0].W -= w1_update



        # Update the second set of weights
        m2 = beta1 * m2 + (1 - beta1) * grad_W2
        v2 = beta2 * v2 + (1 - beta2) * (grad_W2 ** 2)
        m2_hat = m2 / (1 - beta1 ** (i+1))
        v2_hat = v2 / (1 - beta2 ** (i+1))
        w2_update = alpha * m2_hat / (np.sqrt(v2_hat) + epsilon)
        #w2_update[np.isnan(w2_update)] = 0  # Replace NaN with zero
        model.layers[1].W -= w2_update
        if i % 10 == 0:
            loss = np.mean(np.square(model.nn2(train_X) - train_y))
            print("Epoch {}: loss={}".format(i, loss))
            
            
    
    return model.layers[0].W, model.layers[1].W


