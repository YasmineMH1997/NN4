# No additional 3rd party external libraries are allowed
import numpy as np
from numba import cuda, numba


def sync_sgd(model, X_train_batches, y_train_batches, lr=0.1, R=100):
    '''
    Compute gradient estimate of emp loss on each mini batch in-parallel using GPU blocks/threads.
    Wait for all results and aggregate results by calling cuda.synchronize(). For more details, refer to https://thedatafrog.com/en/articles/cuda-kernel-python
    Compute update step synchronously
    '''
    num_batches = len(X_train_batches)

    for epoch in range(R):
        for i in range(num_batches):
            # Forward pass
            # Compute gradient of empirical loss
            grad = model.emp_loss_grad(X_train_batches[i],y_train_batches[i])

            update_step0 = lr * grad[0]
            update_step1 = lr * grad[1]
            update_step2 = lr * grad[2]
            update_step3 = lr * grad[3]
            model.layers[0].W -= update_step0
            model.layers[1].W -= update_step1
            model.layers[2].W -= update_step2
            model.layers[3].W -= update_step3
            lr = lr/1.02  #decaying learning rate over time to help SGD converge

           # if i % 10 == 0:
               ## loss = np.mean(np.square(model.nn4( X_train_batches) - y_train_batches))
              #  print("Epoch {}: loss={}".format(i, loss))

    #cuda.synchronize()  # Wait for all mini-batch updates to complete before continuing
    return model.layers[0].W, model.layers[1].W, model.layers[2].W, model.layers[3].W
@cuda.jit
def sync_sgd_gpu(model, X_train, y_train, lr=0.1, R=100, num_gpus=2):
    device = cuda.get_current_device()
    num_samples = len(X_train)
    batch_size = num_samples // num_gpus
    batches = [(X_train[i*batch_size:(i+1)*batch_size], y_train[i*batch_size:(i+1)*batch_size]) for i in range(num_gpus)]
    
    blockspergrid = (num_gpus, 1, 1)
    threadsperblock = (128, 1, 1)
    
    for i in range(num_gpus):
        device = cuda.select_device(i)
        sync_sgd[blockspergrid, threadsperblock](model, batches[i][0], batches[i][1], lr, R)

    cuda.synchronize()  # Wait for all mini-batch updates to complete before continuing


    return model.layers[0].W, model.layers[1].W, model.layers[2].W, model.layers[3].W