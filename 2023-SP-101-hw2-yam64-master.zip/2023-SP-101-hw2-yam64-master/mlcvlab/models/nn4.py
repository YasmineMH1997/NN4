import numpy as np
from mlcvlab.nn.losses import l2, l2_grad
from mlcvlab.nn.activations import relu, sigmoid, sigmoid_grad, relu_grad
from .base import Layer

from mlcvlab.nn.batchnorm import batchnorm, batchnorm_grad
from mlcvlab.nn.dropout import dropout, dropout_grad

class NN4():
    def __init__(self, use_batchnorm=False, dropout_param=0):
        self.layers = [
            Layer(None, relu),
            Layer(None, relu),
            Layer(None, relu),
            Layer(None, sigmoid)]
        
        self.use_batchnorm = use_batchnorm

        #used in dropout implementation
        self.dropout_param = dropout_param

    def nn4(self, x):
        p = self.dropout_param
        # TODO
        #def batchnorm(x, gamma, beta, eps, train=True):
        if self.use_batchnorm:


            # forward pass
            z1 = np.dot(x, self.layers[0].W)
            z2, d1, mode1, mask1 = dropout(z1, p)     
            a1 = relu(z2)
            z3 = batchnorm(a1)


            z4 = np.dot(z3, self.layers[1].W)
            z5, d2, mode2, mask2 = dropout(z4, p)
            a2 = relu(z5)
            z6 = batchnorm(a2)
            
            z7 = np.dot(z6, self.layers[2].W)
            z8, d3, mode3, mask3 = dropout(z7, p)
            a3 = relu(z8)
            z9 = batchnorm(a3)
           
            z10 = np.dot(z9, self.layers[3].W)
            z11, d4, mode4, mask4 = dropout(z10, p)
            y_pred = sigmoid(z11)

            return y_pred

        else:
            # forward pass
            z1 = np.dot(x, self.layers[0].W.T)
            z2, d1, mode1, mask1 = dropout(z1, p)            
            a1 = relu(z2)


            z4 = np.dot(a1, self.layers[1].W)
            z5, d2, mode2, mask2 = dropout(z4, p)
            a2 = relu(z5)
            
            z6 = np.dot(a2, self.layers[2].W)
            z7, d3, mode3, mask3 = dropout(z6, p)
            a3 = relu(z7)
           
            z9 = np.dot(a3, self.layers[3].W)
            z10, d4, mode4, mask4 = dropout(z9, p)
            y_pred = sigmoid(z10)
            return y_pred

    def grad(self, x, y):
    
        if self.use_batchnorm:
            p = self.dropout_param
            # forward pass
            z1 = np.dot(x, self.layers[0].W)
            z2, d1, mode1, mask1 = dropout(z1, p)           
            a1 = relu(z2)
            z3 = batchnorm(a1)

            z4 = np.dot(z3, self.layers[1].W)
            z5, d2, mode2, mask2 = dropout(z4, p)
            a2 = relu(z5)
            z6 = batchnorm(a2)
            
            z7 = np.dot(z6, self.layers[2].W)
            z8, d3, mode3, mask3 = dropout(z7, p)
            a3 = relu(z8)
            z9 = batchnorm(a3)
           
            z10 = np.dot(z9, self.layers[3].W)
            z11, d4, mode4, mask4 = dropout(z10, p)
            y_pred = sigmoid(z11)
   

            # calculate loss and initial gradient
            dy = l2_grad(y, y_pred)

            # backward pass


            # Output layer
            dz11 = sigmoid_grad(z11) * dy
            dW4 = np.dot(z9.T, dz11)
            


            dz10, dgamma4, dbeta4 = batchnorm_grad(dz11, z9)
            dz9 = relu_grad(z8) * dz10
            dW3 = np.dot(z6.T, dz9)

            dz8, dgamma3, dbeta3 = batchnorm_grad(dz9, z6)
            dz7 = relu_grad(z5) * dropout_grad(np.dot(dz8, self.layers[2].W.T), mask3)
            dW2 = np.dot(z3.T, dz7)

            dz6, dgamma2, dbeta2 = batchnorm_grad(dz7, z3)
            dz5 = relu_grad(z2) * dropout_grad(np.dot(dz6, self.layers[1].W.T), mask2)
            dW1 = np.dot(x.T, dz5)

            # Update weights and biases
            self.layers[0].W -= dW1
            self.layers[1].W -= dW2
            self.layers[2].W -= dW3
            self.layers[3].W -= dW4

            # Update batchnorm parameters
            """self.layers[3].gamma -= dgamma4
            self.layers[3].beta -= dbeta4
            self.layers[2].gamma -=  dgamma3
            self.layers[2].beta -=  dbeta3
            self.layers[1].gamma -=  dgamma2
            self.layers[1].beta -=  dbeta2"""
            
        else:
            p = self.dropout_param
            # forward pass
            z1 = np.dot(x, self.layers[0].W)
            z2, d1, mode1, mask1 = dropout(z1, p)            
            a1 = relu(z2)


            z4 = np.dot(a1, self.layers[1].W)
            z5, d2, mode2, mask2 = dropout(z4, p)
            a2 = relu(z5)
            
            z6 = np.dot(a2, self.layers[2].W)
            z7, d3, mode3, mask3 = dropout(z6, p)
            a3 = relu(z7)
           
            z9 = np.dot(a3, self.layers[3].W)
            z10, d4, mode4, mask4 = dropout(z9, p)
            y_pred = sigmoid(z10)

            # calculate loss and initial gradient
            dloss = l2_grad(y, y_pred)


            #backward pass
            dy = dloss * sigmoid_grad(y_pred)
            dz10 = dy * d4
            da3 = np.dot(dz10, self.layers[3].W.T)
            dz9 = dropout_grad(da3, mask4) * d3
            da2 = np.dot(dz9, self.layers[2].W.T)
            dz7 = dropout_grad(da2, mask3) * d2
            da1 = np.dot(dz7, self.layers[1].W.T)
            dz5 = dropout_grad(da1, mask2) * d1
            dz4 = relu_grad(z5) * dz5
            dz3, dgamma3, dbeta3 = batchnorm_grad(dz4, a2)
            da2 = np.dot(dz3, self.layers[2].W.T)
            dz6 = dropout_grad(da2, mask3)
            dz2 = relu_grad(z2) * dropout_grad(np.dot(dz6, self.layers[1].W.T), mask2)
            dz1 = dropout_grad(np.dot(dz2, self.layers[0].W.T), mask1)
            dW4 = np.dot(a3.T, dz10)
            dW3 = np.dot(a2.T, dz9)
            dW2 = np.dot(a1.T, dz7)
            dW1 = np.dot(x.T, dz1)

            # update gradients in layers
            self.layers[0].W -= dW1
            self.layers[1].W -= dW2
            self.layers[2].W -= dW3
            self.layers[3].W -= dW4

        return dW1, dW2, dW3, dW4


    def emp_loss_grad(self, train_X, train_y):
     # Calculate the empirical loss gradient

        """Removed the for loop for faster running time and  make use of the numpy operations 
        that can perform forward and backward pass over the whole training data (60000 images)."""

        n = train_X.shape[0]

        grad_W0, grad_W1, grad_W2, grad_W3 = self.grad(train_X, train_y)

        # Divide by the number of examples to get the average gradient
        grad_W0 /= n
        grad_W1 /= n
        grad_W2 /= n
        grad_W3 /= n

        self.layers[0].W = grad_W0
        self.layers[1].W = grad_W1
        self.layers[2].W = grad_W2
        self.layers[3].W = grad_W3

        # Return the updated weights
        return grad_W0, grad_W1, grad_W2, grad_W3
